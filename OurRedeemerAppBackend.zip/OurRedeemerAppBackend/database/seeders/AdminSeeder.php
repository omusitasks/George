<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $admin = User::create([
            'name' => 'Admin',
            'email' => 'admin@gmail.com',
            'email_verified_at' => now(),
            'password' => bcrypt('testing'),// password
        ]);

        $admin->assignRole('admin');

        $permission = Permission::create(['name' => 'Role access']);
        $permission = Permission::create(['name' => 'Role edit']);
        $permission = Permission::create(['name' => 'Role create']);
        $permission = Permission::create(['name' => 'Role delete']);

        $permission = Permission::create(['name' => 'User access']);
        $permission = Permission::create(['name' => 'User edit']);
        $permission = Permission::create(['name' => 'User create']);
        $permission = Permission::create(['name' => 'User delete']);
        $permission = Permission::create(['name' => 'User update role']);

        $permission = Permission::create(['name' => 'Permission access']);
        $permission = Permission::create(['name' => 'Permission edit']);
        $permission = Permission::create(['name' => 'Permission create']);
        $permission = Permission::create(['name' => 'Permission delete']);

        $permission = Permission::create(['name' => 'Radio access']);
        $permission = Permission::create(['name' => 'Radio edit']);
        $permission = Permission::create(['name' => 'Radio create']);
        $permission = Permission::create(['name' => 'Radio delete']);

        $permission = Permission::create(['name' => 'SystemInfo access']);
        $permission = Permission::create(['name' => 'SystemInfo edit']);
        $permission = Permission::create(['name' => 'SystemInfo create']);
        $permission = Permission::create(['name' => 'SystemInfo delete']);


        $admin->givePermissionTo(Permission::all());
    }
}

