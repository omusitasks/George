    <!-- Backend Bundle JavaScript -->
    <script src="{{ asset('backend/assets') }}/js/backend-bundle.min.js"></script>
    
    <!-- Table Treeview JavaScript -->
    <script src="{{ asset('backend/assets') }}/js/table-treeview.js"></script>
    
    <!-- Chart Custom JavaScript -->
    <script src="{{ asset('backend/assets') }}/js/customizer.js"></script>
    
    <!-- Chart Custom JavaScript -->
    <script async src="{{ asset('backend/assets') }}/js/chart-custom.js"></script>
    
    <!-- app JavaScript -->
    <script src="{{ asset('backend/assets') }}/js/app.js"></script>

    {{-- jquery --}}
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!--dataTable-->
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.colVis.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js"></script>

    <!-- toastr   -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        @if(Session::has('message'))
        var type = "{{ Session::get('alert-type','info') }}"
        switch(type){
            case 'info':
            toastr.info(" {{ Session::get('message') }} ");
            break;

            case 'success':
            toastr.success(" {{ Session::get('message') }} ");
            break;

            case 'warning':
            toastr.warning(" {{ Session::get('message') }} ");
            break;

            case 'error':
            toastr.error(" {{ Session::get('message') }} ");
            break;
        }
        @endif
    </script>


    <!-- image upload time show   -->
    <script type="text/javascript">
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#image')
                        .attr('src', e.target.result);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        
    </script>


    <script>
        // Function to add leading zeros
        function addLeadingZero(number) {
            return (number < 10 ? '0' : '') + number;
        }

        // Function to update time
        function updateTime() {
            var currentDate = new Date();

            // Format the date as "Month day, year"
            var formattedDate = currentDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

            // Format the time as "hh:mm:ss"
            var formattedTime = addLeadingZero(currentDate.getHours()) + ':' + addLeadingZero(currentDate.getMinutes()) + ':' + addLeadingZero(currentDate.getSeconds());

        
            // Update the content of the paragraph element
        document.getElementById('datePlaceholder').innerHTML = 'Since ' + formattedDate + ' | ' + formattedTime;
        }

        // Initial call to display time immediately
        updateTime();

        // Update time every second
        setInterval(updateTime, 1000);
    </script>


<!-- listerners count -->
<!-- JavaScript code to update listeners count without refreshing -->
<script>
    function updateListenersCount() {
        // Generate a random number between 0 and 1000
        const randomCount = Math.floor(Math.random() * 350);
        // Update the listeners count in the HTML
        document.getElementById('listenersCount').textContent = randomCount;
    }

    // Call the update function initially
    updateListenersCount();

    // Set up a timer to periodically update the count every 15 seconds
    setInterval(updateListenersCount, 10000); // 15 seconds in milliseconds
</script>