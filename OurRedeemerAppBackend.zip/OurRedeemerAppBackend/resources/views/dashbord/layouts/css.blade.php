<!-- Favicon -->
<link rel="shortcut icon" href="{{ asset('backend/assets') }}/images/favicon.ico" />
<link rel="stylesheet" href="{{ asset('backend/assets') }}/css/backend-plugin.min.css">
<link rel="stylesheet" href="{{ asset('backend/assets') }}/css/backend.css?v=1.0.0">
<link rel="stylesheet" href="{{ asset('backend/assets') }}/vendor/@fortawesome/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="{{ asset('backend/assets') }}/vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css">
<link rel="stylesheet" href="{{ asset('backend/assets') }}/vendor/remixicon/fonts/remixicon.css">  

<!--toastr-->
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" >

<!--DataTable-->

<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>  
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script> 



