<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>Dashbord | Update Radio</title>
      
      {{-- css --}}
      @include('dashbord.layouts.css')
    </head>
  <body class="  ">
    <!-- loader Start -->
    <div id="loading">
          <div id="loading-center">
          </div>
    </div>
    <!-- loader END -->
    <!-- Wrapper Start -->
    <div class="wrapper">
      {{-- left navbar --}}
        @include('dashbord.layouts.left_nav');

        {{-- top navbar --}}
        @include('dashbord.layouts.top_nav')

      <div class="content-page">
        {{-- main page --}}
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex flex-wrap align-items-center justify-content-between mb-4">
                        <div>

                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb ">
                                   <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-danger"><i class="ri-home-4-line mr-1 float-left"></i>Dashbord</a></li>
                                   <li class="breadcrumb-item"><a href="{{ route('radios.index') }}" class="text-danger">Radio List</a></li>
                                   <li class="breadcrumb-item active" aria-current="page">Edit Radio</li>
                                </ol>
                             </nav>

                            <h4 class="mb-3">Edit Radio</h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <form action="{{ route('radios.update',$radio->id) }}" method="POST">
                      @csrf
                      @method("PUT")
                        <div class="form-group">
                           <div class="row">
                           <div class="col-md-4">
                           <label for="exampleInputText">Title</label>
                              <input type="text" class="form-control" id="exampleInputText" value="{{ $radio->title }}" name="title"
                                 placeholder="Enter title">
                           </div>
                           <div class="col-md-4">
                              <label for="exampleInputText">Subtitle</label>
                              <input type="text" class="form-control" id="exampleInputText" value="{{ $radio->subtitle }}" name="subtitle"
                                 placeholder="Enter subtitle">
                           </div>
                           <div class="col-md-4">
                              <label for="exampleInputText">Votes</label>
                              <input type="number" class="form-control" id="exampleInputText" value="{{ $radio->votes }}" name="votes"
                                 placeholder="Enter votes">
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-md-4">
                              <label for="exampleInputText">Logo</label>
                              <input type="text" class="form-control" id="exampleInputText" value="{{ $radio->image }}" name="image"
                                 placeholder="Enter logo path">
                              <!-- <input type="file" accept="image/*" class="form-control" id="exampleInputImage" value="{{ $radio->image }}" 
                                 name="image"> -->
                           </div>
                           <div class="col-md-8">
                              <label for="exampleInputText">Streaming URL</label>
                              <input type="url" class="form-control" id="exampleInputText" value="{{ $radio->audio_url }}" name="audio_url"
                                 placeholder="e.g., https://www.amazon.com">
                           </div>
                        </div>
                            @error('name')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror

                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                     </form>
                   
                </div>
            </div>
        


        </div>
            <!-- Page end  -->
        </div>
      </div>
    </div>

  {{-- js --}}
  @include('dashbord.layouts.js')
  </body>
</html>