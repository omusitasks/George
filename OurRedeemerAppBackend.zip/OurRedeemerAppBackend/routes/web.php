<?php

use App\Http\Controllers\Dashbord\AttendanceController as AttendanceController;
use App\Http\Controllers\Dashbord\ClassesController as ClassesController;
use App\Http\Controllers\Dashbord\ExamController as ExamController;
use App\Http\Controllers\Dashbord\ExamMarksRegistrationController;
use App\Http\Controllers\Dashbord\ExamScheduleController as ExamScheduleController;
use App\Http\Controllers\Dashbord\ExpenseController as ExpenseController;
use App\Http\Controllers\Dashbord\FeeCollectionController as FeeCollectionController;
use App\Http\Controllers\Dashbord\PermissionController as PermissionController;
use App\Http\Controllers\Dashbord\ResultController as ResultController;
use App\Http\Controllers\Dashbord\RoleController as RoleController;
use App\Http\Controllers\Dashbord\SalaryController as SalaryController;
use App\Http\Controllers\Dashbord\SalarysheetController;
use App\Http\Controllers\Dashbord\StudentController as StudentController;
use App\Http\Controllers\Dashbord\StudentPromotionController as StudentPromotionController;
use App\Http\Controllers\Dashbord\SubjectController as SubjectController;
use App\Http\Controllers\Dashbord\UserController as UserController;
use App\Http\Controllers\Dashbord\ProfileController as ProfileController;

use App\Http\Controllers\Dashbord\RadioController as RadioController;
use App\Http\Controllers\Dashbord\SystemInfoController as SystemInfoController;
// use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;


// MAIN DASHBOARD
use App\Http\Controllers\Dashbord\MainDashboardController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/dashboard', [MainDashboardController::class, 'index'])
    ->middleware(['auth', 'verified'])
    ->name('dashboard');


// Route::get('/dashboard', function () {
//     // return view('dashboard');
//     return view('dashbord.maniDashbord');
// })->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

/**
 * -------------------------------------------------
 * ---------------------Dashbord Controller-------------->
 * -------------------------------------------------
 */
Route::middleware(['auth'])->group(function () {
    /**
     * Role Controller
     */
    Route::resource('/roles', RoleController::class);
    Route::post('/attach/{role}', [RoleController::class, 'attachPermissions'])->name('permissions.attach');
    Route::DELETE('/role/{role}/permission/{permission}', [RoleController::class, 'revokPermissions'])->name('permissions.revok');

    /**
     * Permission Controller
     */
    Route::resource('/permissions', PermissionController::class);
    Route::post('/attach/role/{permission}', [PermissionController::class, 'attachRole'])->name('role.attach');
    Route::DELETE('/permission/{permission}/role/{role}/', [PermissionController::class, 'revokRole'])->name('role.revok');

    /**
     * User Controller
     */
    Route::resource('/users', UserController::class);
    Route::post('/user/role/update/{user}', [UserController::class, 'userUpdateRole'])->name('userUpdate.role');

    /**
     * Student Controller
     */
    Route::resource('/students', StudentController::class);

    /**
     * Classes Controller
     */
    Route::resource('/classes', ClassesController::class);


    /**
     * RadioController  
     */

    Route::resource('/radios', RadioController::class);
    Route::get('/radios/{id}', [RadioController::class, 'show'])->name('radios.show');
    Route::get('/radios/{id}/edit', [RadioController::class, 'edit'])->name('radios.edit');
    Route::patch('/radios/{id}', [RadioController::class, 'update'])->name('radios.update');
    Route::delete('/radios/{id}', [RadioController::class, 'destroy'])->name('radios.destroy');

    



    /**
     * SystemInfoController
     */

    Route::resource('/systemInfo', SystemInfoController::class);
    Route::get('/systemInfo/{id}', [SystemInfoController::class, 'show'])->name('systemInfo.show');
    Route::get('/systemInfo/{id}/edit', [SystemInfoController::class, 'edit'])->name('systemInfo.edit');
    Route::patch('/systemInfo/{id}', [SystemInfoController::class, 'update'])->name('systemInfo.update');
    Route::delete('/systemInfo/{id}', [SystemInfoController::class, 'destroy'])->name('systemInfo.destroy');

});

require __DIR__.'/auth.php';
