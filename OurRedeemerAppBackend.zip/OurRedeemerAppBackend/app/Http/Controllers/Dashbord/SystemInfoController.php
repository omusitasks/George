<?php

namespace App\Http\Controllers\Dashbord;

use App\Http\Controllers\Dashbord\BaseController as BaseController;

use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

use Illuminate\Support\Facades\DB;


class SystemInfoController extends BaseController
{
    public function __construct()
    {
        $this->middleware('role_or_permission:SystemInfo access|SystemInfo create|SystemInfo edit|SystemInfo delete', ['only' => ['index', 'show']]);
        $this->middleware('role_or_permission:SystemInfo create', ['only' => ['create', 'store']]);
        $this->middleware('role_or_permission:SystemInfo edit', ['only' => ['edit', 'update']]);
        $this->middleware('role_or_permission:SystemInfo delete', ['only' => ['destroy']]);
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $systemInfo = DB::table('system_info')->latest()->get();

        return view('dashbord.systeminfo.index', compact('systemInfo'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $systemInfo = DB::table('system_info')->latest()->get();

        return view('dashbord.systeminfo.create', compact('systemInfo'));
    }


    /**
     * Store a newly created resource in storage.
     */

     public function store(Request $request)
     {
         $request->validate([
             'name' => 'required|max:50',
             'description' => 'nullable|max:500',
             'system_logo' => 'nullable',
             'system_about_us'=> 'nullable|max:500',
             'system_email' => 'required|max:500',
             'system_contact' => 'required|max:500',
         ]);
     
         // Check if the name already exists
         $nameExists = DB::table('system_info')->where('name', $request->name)->exists();
     
         if ($nameExists) {
             return $this->returnMessage('That name already exists!', 'error');
         }
     
         // Insert the data into the database
         DB::table('system_info')->insert([
             'name' => $request->name,
             'description' => $request->description,
             'system_logo' => $request->system_logo,
             'system_about_us' => $request->system_about_us,
             'system_email' => $request->system_email,
             'system_contact' => $request->system_contact,
             'created_by' => auth()->id(),
             'created_at' => now(),
         ]);
     
         return $this->returnMessage('System Information added successfully', 'success');
     }
     
     
     
     


    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $systemInfo = DB::table('system_info')
            ->join('users', 'system_info.created_by', '=', 'users.id')
            ->select('system_info.*', 'users.name as author')
            ->where('system_info.id', $id)
            ->first();

        if (!$systemInfo) {
            abort(404);
        }

        $createdDate = Carbon::parse($systemInfo->created_at);
        $duration = $createdDate->diffForHumans();

        return view('dashbord.systeminfo.show', compact('systemInfo', 'duration'));
    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $systemInfo = DB::table('system_info')->find($id);

        if (!$systemInfo) {
            abort(404);
        }

        return view('dashbord.systeminfo.edit', compact('systemInfo'));
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|max:50|unique:system_info,name,'.$id,
             'description' => 'nullable|max:500',
             'system_logo' => 'nullable',
             'system_about_us'=> 'nullable|max:500',
             'system_email' => 'required|max:500',
             'system_contact' => 'required|max:500',
        ]);

        $systemInfo = DB::table('system_info')->find($id);

        if (!$systemInfo) {
            abort(404);
        }

        // Check if the name already exists and it's not the current name
    $nameExists = DB::table('system_info')->where('name', $request->name)->where('id', '!=', $id)->exists();
 
    if ($nameExists) {
        return $this->returnMessage('That name already exists!', 'error');
    }

        DB::table('system_info')
            ->where('id', $id)
            ->update([
            'name' => $request->name,
            'description' => $request->description,
            'system_logo' => $request->system_logo,
             'system_about_us' => $request->system_about_us,
             'system_email' => $request->system_email,
             'system_contact' => $request->system_contact,
                'updated_by' => auth()->id(),
                'updated_at' => now(),
            ]);

        return $this->returnMessage('System Information successfully', 'success');
    }




    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        DB::table('system_info')->where('id', $id)->delete();

        return $this->returnMessage('System Information deleted successfully', 'success');
    }
  
}
