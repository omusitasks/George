<?php

namespace App\Http\Controllers\Dashbord;

use App\Http\Controllers\Dashbord\BaseController as BaseController;

use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

use Illuminate\Support\Facades\DB;

class RadioController extends BaseController
{
    public function __construct()
    {
        $this->middleware('role_or_permission:Radio access|Radio create|Radio edit|Radio delete', ['only' => ['index', 'show']]);
        $this->middleware('role_or_permission:Radio create', ['only' => ['create', 'store']]);
        $this->middleware('role_or_permission:Radio edit', ['only' => ['edit', 'update']]);
        $this->middleware('role_or_permission:Radio delete', ['only' => ['destroy']]);
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $radios = DB::table('radios')->latest()->get();


        return view('dashbord.Radios.index', compact('radios'));
    }

    // for API ROUTE
    public function api_route(Request $request)
{
    $radios = DB::table('radios')->latest()->get();

    return response()->json($radios);
}


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $radios = DB::table('radios')->latest()->get();

        return view('dashbord.Radios.create', compact('radios'));
    }


    /**
     * Store a newly created resource in storage.
     */

     public function store(Request $request)
     {
         $request->validate([
             'title' => 'required|max:50',
             'subtitle' => 'nullable|max:500',
             'votes' => 'nullable',
             'image'=> 'nullable|max:500',
             'audio_url' => 'required|max:500',
         ]);
     
         // Check if the title already exists
         $titleExists = DB::table('radios')->where('title', $request->title)->exists();
     
         if ($titleExists) {
             return $this->returnMessage('That title already exists!', 'error');
         }
     
         // Insert the data into the database
         DB::table('radios')->insert([
             'title' => $request->title,
             'subtitle' => $request->subtitle,
             'votes' => $request->votes,
             'image' => $request->image,
             'audio_url' => $request->audio_url,
             'created_by' => auth()->id(),
             'created_at' => now(),
         ]);
     
         return $this->returnMessage('Radio added successfully', 'success');
     }
     
     
     
     


    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $radio = DB::table('radios')
            ->join('users', 'radios.created_by', '=', 'users.id')
            ->select('radios.*', 'users.name as author')
            ->where('radios.id', $id)
            ->first();

        if (!$radio) {
            abort(404);
        }

        $createdDate = Carbon::parse($radio->created_at);
        $duration = $createdDate->diffForHumans();

        return view('dashbord.Radios.show', compact('radio', 'duration'));
    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $radio = DB::table('radios')->find($id);

        if (!$radio) {
            abort(404);
        }

        return view('dashbord.Radios.edit', compact('radio'));
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|max:50|unique:radios,title,'.$id,
            'subtitle' => 'nullable|max:500',
            'votes' => 'nullable',
            'image'=> 'nullable|max:500',
            // 'image' => 'mimes:png,jpg,jpeg',
            'audio_url' => 'required|max:500',
        ]);

        $radio = DB::table('radios')->find($id);

        if (!$radio) {
            abort(404);
        }

        // Check if the title already exists and it's not the current title
    $titleExists = DB::table('radios')->where('title', $request->title)->where('id', '!=', $id)->exists();
 
    if ($titleExists) {
        return $this->returnMessage('That title already exists!', 'error');
    }

        DB::table('radios')
            ->where('id', $id)
            ->update([
                'title' => $request->title,
                'subtitle' => $request->subtitle,
                'votes' => $request->votes,
                'image' => $request->image,
                'audio_url' => $request->audio_url,
                'updated_by' => auth()->id(),
                'updated_at' => now(),
            ]);

        return $this->returnMessage('Radio updated successfully', 'success');
    }




    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        DB::table('radios')->where('id', $id)->delete();

        return $this->returnMessage('Radio deleted successfully', 'success');
    }

}
