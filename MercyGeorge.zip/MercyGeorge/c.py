def convert_py_to_txt(py_file_path, txt_file_path):
    # Open the .py file in read mode
    with open(py_file_path, 'r') as py_file:
        content = py_file.read()

    # Open the .txt file in write mode
    with open(txt_file_path, 'w') as txt_file:
        txt_file.write(content)

    print(f"File '{py_file_path}' has been successfully converted to '{txt_file_path}'")

# Example usage
convert_py_to_txt('problemc_impelemtation.py', 'problemc_impelemtation.txt')
