import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression, PoissonRegressor
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from statsmodels.tsa.arima.model import ARIMA
import pymc as pm
from sklearn.metrics import mean_squared_error

# Load and preprocess data
# Load and preprocess data
def load_data(medal_counts_path, hosts_path, programs_path, athletes_path):
    # Load datasets
    medal_counts = pd.read_csv(medal_counts_path, delimiter=';', encoding="ISO-8859-1")
    hosts = pd.read_csv(hosts_path, delimiter=';', encoding="ISO-8859-1")
    programs = pd.read_csv(programs_path, delimiter=';', encoding="ISO-8859-1")
    athletes = pd.read_csv(athletes_path, delimiter=';', encoding="ISO-8859-1")
    
    # Merge medal_counts with hosts to include host country information
    data = medal_counts.merge(hosts, on='Year', how='left')
    
    # Feature engineering: Create dummy variable for host country
    data['Host_Country'] = np.where(data['Country'] == data['Host'], 1, 0)
    
    # Optional preprocessing steps:
    # Handle missing values
    data.fillna(0, inplace=True)
    
    # Convert data types if necessary
    data['Medals'] = data['Medals'].astype(int)
    
    # Return preprocessed data and other datasets if needed
    return data, programs, athletes


# Regression Models
def multiple_linear_regression(data):
    X = data[['Past_Medals', 'Host_Country']]
    y = data['Current_Medals']
    model = LinearRegression()
    scores = cross_val_score(model, X, y, cv=5, scoring='neg_mean_squared_error')
    print("MLR Cross-Validation MSE:", -np.mean(scores))
    model.fit(X, y)
    return model

def poisson_regression(data):
    X = data[['Past_Medals', 'Host_Country']]
    y = data['Current_Medals']
    model = PoissonRegressor(alpha=1e-12, max_iter=300)
    model.fit(X, y)
    predictions = model.predict(X)
    mse = mean_squared_error(y, predictions)
    print("Poisson Regression MSE:", mse)
    return model

# Time Series Forecasting
def arima_forecasting(data, country):
    country_data = data[data['Country'] == country]
    medals = country_data['Current_Medals']
    model = ARIMA(medals, order=(1, 1, 1))
    fitted_model = model.fit()
    print(fitted_model.summary())
    return fitted_model

# Machine Learning Models
def train_random_forest(data):
    X = data[['Past_Medals', 'Host_Country']]
    y = data['Current_Medals']
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X, y)
    print("Feature Importances:", model.feature_importances_)
    return model

def train_xgboost(data):
    X = data[['Past_Medals', 'Host_Country']]
    y = data['Current_Medals']
    model = XGBRegressor(objective='reg:squarederror', n_estimators=100, learning_rate=0.1)
    model.fit(X, y)
    return model

# Bayesian Hierarchical Model
def bayesian_hierarchical_model(data):
    with pm.Model() as model:
        # Hyperpriors
        mu_a = pm.Normal('mu_a', mu=0, sigma=10)
        sigma_a = pm.HalfNormal('sigma_a', sigma=10)

        # Country-level effects
        a = pm.Normal('a', mu=mu_a, sigma=sigma_a, shape=data['Country'].nunique())

        # Expected value
        expected_medals = a[data['Country_Index']]

        # Observed medals
        y_obs = pm.Poisson('y_obs', mu=expected_medals, observed=data['Current_Medals'])

        trace = pm.sample(1000, return_inferencedata=True)
    return trace


# Example usage
def main():
    # Filepaths for datasets
    medal_counts_path = "summerOly_medal_counts.csv"
    hosts_path = "summerOly_hosts.csv"
    programs_path = "summerOly_programs.csv"
    athletes_path = "summerOly_athletes.csv"
    
    # Load and preprocess the data
    print("Loading data...")
    medal_data, programs_data, athletes_data = load_data(
        medal_counts_path,
        hosts_path,
        programs_path,
        athletes_path
    )

    print("Training Multiple Linear Regression Model...")
    mlr_model = multiple_linear_regression(medal_data)

    print("Training Poisson Regression Model...")
    poisson_model = poisson_regression(medal_data)

    print("ARIMA Forecasting for USA...")
    arima_model = arima_forecasting(medal_data, 'USA')

    print("Training Random Forest Model...")
    rf_model = train_random_forest(medal_data)

    print("Training XGBoost Model...")
    xgb_model = train_xgboost(medal_data)

    print("Running Bayesian Hierarchical Model...")
    trace = bayesian_hierarchical_model(medal_data)

if __name__ == "__main__":
    main()
