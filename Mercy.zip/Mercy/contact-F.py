#!/usr/bin/env python3
"""Analyse a vampire infiltration.
   Vampire Hunting v1.4.4

   Student number:
"""

import sys
import os.path
from format_list import format_list, format_list_or, str_time, is_initial, period_of_time, day_of_time, time_of_day

import os
import sys

# Section 2: Check the file exists
def file_exists(file_name):
    """Verify that the file exists.

    Args:
        file_name (str): name of the file

    Returns:
        boolean: returns True if the file exists and False otherwise.
    """
    return os.path.isfile(file_name)

# Section 3: Parse the file and extract the relevant data
def parse_file(file_name):
    """Read the input file, parse the contents and return some data structures
    that contain the associated data for the vampire infiltration.

    Args:
        file_name (str): Contains the name of the file.

    Returns:
        participants: list of participants.
        days: list of pairs; the first element of a pair is the result of tests
          (dictionary from participants to "H"/"V"); the second is a list of
          contact groups (list of lists of participants)
    """
    participants = []
    days = []

    try:
        with open(file_name, 'r') as f:
            # Read the first line: Participants list
            participants_line = f.readline().strip()
            participants = [name.strip() for name in participants_line.split(',')]

            # Read the second line: Number of days
            num_days_line = f.readline().strip()
            num_days = int(num_days_line)

            for _ in range(num_days):
                # Read the test results for the day
                test_results_line = f.readline().strip()
                if test_results_line != "##":
                    test_results = {}
                    test_results_parts = test_results_line.split(',')
                    for part in test_results_parts:
                        name, result = part.split(':')
                        test_results[name.strip()] = True if result.strip() == 'V' else False
                else:
                    test_results = {}

                # Read the number of contact groups
                num_groups_line = f.readline().strip()
                num_groups = int(num_groups_line)

                # Read the contact groups
                contact_groups = []
                for _ in range(num_groups):
                    contact_group_line = f.readline().strip()
                    contact_group = [name.strip() for name in contact_group_line.split(',')]
                    contact_groups.append(contact_group)

                # Store the day's data as a tuple of test results and contact groups
                days.append((test_results, contact_groups))

            return (participants, days)
    
    except ValueError:
        # Handle errors in case of incorrect data format (e.g., non-integer values)
        print("Error found in file, aborting.")
        sys.exit()
    except Exception as e:
        # Handle any other errors, like file not found
        print(f"Error reading file: {e}")
        sys.exit()

#section 4
def pretty_print_infiltration_data(data):
    """Pretty print the vampire infiltration data in a human-readable format."""
    
    # Header
    print("Vampire Infiltration Data")
    
    # Participants and Day Count
    participants = data[0]
    num_days = len(data[1])
    print(f"{num_days} days with the following participants: {format_list(participants)}.")
    
    # Iterate through each day and print the relevant information
    for day_num, day_data in enumerate(data[1], start=1):
        # Extract vampire test results and contact groups
        vampire_tests, contact_groups = day_data
        test_results = sorted(vampire_tests.items())  # Sort by participant names
        
        # Day number and number of tests/groups
        num_tests = len(test_results)
        num_groups = len(contact_groups)
        print(f"Day {day_num} has {num_tests} vampire test{'s' if num_tests > 1 else ''} and {num_groups} contact group{'s' if num_groups > 1 else ''}.")
        
        # Print test results (2 spaces indent, 4 spaces for each participant)
        print(f"  {num_tests} test{'s' if num_tests > 1 else ''}")
        for participant, is_vampire in test_results:
            status = "vampire!" if is_vampire else "human."
            print(f"    {participant} is a {status}")
        
        # Print contact groups (2 spaces indent, 4 spaces for each group)
        print(f"  {num_groups} group{'s' if num_groups > 1 else ''}")
        for group in contact_groups:
            print(f"    {', '.join(group)}")
    
    # End of the data
    print("End of Days")

# Section 5
def contacts_by_time(participant, time, contacts_daily):
    """
    Returns a list of participants that the given participant (participant) met on the specified time (time unit).
    
    Args:
        participant (str): The name of the participant.
        time (int): The time unit (AM or PM), which corresponds to the day and period.
        contacts_daily (list): A list of contact groups for each day.
        
    Returns:
        list: A list of participants the given participant met at the specified time.
    """
    # If the time is in the initial period (day 0), there are no contacts.
    if time == 0:
        return []

    # Convert the time unit into the corresponding day (1-based index).
    day = day_of_time(time) - 1  # Convert to 0-based index for contacts_daily

    # If it's day 0, return an empty list since there are no contacts on day 0.
    if day == 0:
        return []

    # Get the contact groups for the given day.
    groups = contacts_daily[day]

    # Initialize an empty list to store contacts for the given participant.
    participant_contacts = []

    # Search through the groups for the given day to find the participant and their contacts.
    for group in groups:
        if participant in group:
            # Add all participants from this group (except the current participant).
            participant_contacts.extend([p for p in group if p != participant])

    # Return the list of contacts for the given participant at the specified time.
    return participant_contacts
    
# Section 6

def create_initial_vk(participants):
    """Create the initial vampire knowledge structure with all participants having 'U' (unclear) status."""
    # Initialize the dictionary with all participants marked as unclear ('U')
    return {participant: 'U' for participant in participants}

def pretty_print_vampire_knowledge(vk):
    """Pretty print the current vampire knowledge structure."""
    # Categorize participants based on their status
    humans = sorted([name for name, status in vk.items() if status == 'H'])
    vampires = sorted([name for name, status in vk.items() if status == 'V'])
    unclear = sorted([name for name, status in vk.items() if status == 'U'])

    # Format and print each category
    print(f"  Humans: {format_list(humans)}")
    print(f"  Unclear individuals: {format_list(unclear)}")
    print(f"  Vampires: {format_list(vampires)}")

# Done by professors
def pretty_print_vks(vks):
    """Pretty print the vampire knowledge for each day."""
    print(f'Vampire Knowledge Tables')
    for i in range(len(vks)):
        print(f'Day {str_time(i)}:')
        pretty_print_vampire_knowledge(vks[i])
    print(f'End Vampire Knowledge Tables')  # Section 6. Create the initial data structure and pretty-print it.

# Section 7
import sys

def update_vk_with_tests(vk, tests):
    """Update the vampire knowledge structure with test results."""
    # Iterate over each participant in the tests dictionary
    for participant, test_result in tests.items():
        # Check if the participant is valid
        if participant not in vk:
            print(f"Error found in data: test subject is not a participant; aborting.")
            sys.exit()
        
        current_status = vk[participant]
        
        # Check if there are errors based on the current status and test result
        if current_status == 'H' and test_result:  # Human tests positive for vampirism
            print(f"Error found in data: humans cannot be vampires; aborting.")
            sys.exit()
        elif current_status == 'V' and not test_result:  # Vampire tests negative for vampirism
            print(f"Error found in data: vampires cannot be humans; aborting.")
            sys.exit()
        
        # Update the status if the current status is unclear ('U')
        if current_status == 'U':
            if test_result:  # Positive test, mark as vampire
                vk[participant] = 'V'
            else:  # Negative test, mark as human
                vk[participant] = 'H'
    
    return vk

# Done by professors
def pretty_print_vks(vks):
    """Pretty print the vampire knowledge for each day."""
    print(f'Vampire Knowledge Tables')
    for i in range(len(vks)):
        print(f'Day {str_time(i)}:')
        pretty_print_vampire_knowledge(vks[i])
    print(f'End Vampire Knowledge Tables')


# Section 8
def update_vk_with_vampires_forward(vk_pre, vk_post):
    """ Propagate vampire status from the pre-period (vk_pre) to the post-period (vk_post). """
    
    for participant, pre_status in vk_pre.items():
        post_status = vk_post.get(participant, 'U')  # Default to 'U' if participant is not in vk_post
        
        if pre_status == 'V':  # The participant is a vampire in vk_pre
            if post_status == 'H':  # Error: A vampire cannot be human
                print("Error found in data: vampires cannot be humans; aborting.")
                sys.exit()
            elif post_status == 'U':  # Update unknown status to vampire
                vk_post[participant] = 'V'
        
        # If the participant wasn't a vampire in vk_pre, no change is made in vk_post
        # Only propagate if they are confirmed as a vampire in vk_pre
    
    return vk_post
# Section 9
import sys

def update_vk_with_humans_backward(vk_pre, vk_post):
    """ Propagate human status from the post-period (vk_post) to the pre-period (vk_pre). """
    
    for participant, post_status in vk_post.items():
        pre_status = vk_pre.get(participant, 'U')  # Default to 'U' if participant is not in vk_pre
        
        if post_status == 'H':  # The participant is human in vk_post
            if pre_status == 'V':  # Error: A human cannot be a vampire in the past
                print("Error found in data: humans cannot be vampires; aborting.")
                sys.exit()
            elif pre_status == 'U':  # Update unknown status to human
                vk_pre[participant] = 'H'
        
        # If the participant was not human in vk_post, no change is made in vk_pre
    
    return vk_pre


# Section 10
import sys

def update_vk_overnight(vk_pre, vk_post):
    """
    Propagate human/vampire status forward overnight.
    
    Logical principle 4: Everyone is safe at night. Humans remain human.
    
    Args:
        vk_pre (dict): Vampire knowledge structure before overnight period
        vk_post (dict): Vampire knowledge structure after overnight period
    
    Returns:
        dict: Updated post-overnight vampire knowledge structure
    """
    for participant, pre_status in vk_pre.items():
        post_status = vk_post.get(participant, 'U')  # Default to 'U' if not in post
        
        # Error conditions
        if pre_status == 'H' and post_status == 'V':
            print("Error found in data: humans cannot be vampires; aborting.")
            sys.exit()
        elif pre_status == 'V' and post_status == 'H':
            print("Error found in data: vampires cannot be humans; aborting.")
            sys.exit()
        
        # Propagate definite statuses
        if pre_status == 'H' and post_status == 'U':
            vk_post[participant] = 'H'
        elif pre_status == 'V' and post_status == 'U':
            vk_post[participant] = 'V'
    
    return vk_post

def update_vk_with_contact_group(vk_pre, contacts, vk_post):
    """
    Update vampire knowledge based on contact groups.
    
    Logical principle 5: Vampires might turn humans during contacts.
    
    Args:
        vk_pre (dict): Vampire knowledge structure before contacts
        contacts (list): List of contact groups (each group is a list of participants)
        vk_post (dict): Vampire knowledge structure after contacts
    
    Returns:
        dict: Updated post-contact vampire knowledge structure
    """
    # First, validate participants and propagate known vampire statuses
    for participant, pre_status in vk_pre.items():
        post_status = vk_post.get(participant, 'U')
        
        # Check for impossible status transitions
        if pre_status == 'V' and post_status == 'H':
            print("Error found in data: vampires cannot be human; aborting.")
            sys.exit()
        
        # Propagate known vampire status
        if pre_status == 'V' and post_status == 'U':
            vk_post[participant] = 'V'
    
    # Validate contact group participants
    for group in contacts:
        for participant in group:
            if participant not in vk_pre:
                print("Error found in data: contact subject is not a participant; aborting.")
                sys.exit()
    
    # Process non-contact participants
    all_contact_participants = set(participant 
                                   for group in contacts 
                                   for participant in group)
    
    for participant, pre_status in vk_pre.items():
        if participant not in all_contact_participants:
            post_status = vk_post.get(participant, 'U')
            
            # Propagate known human status for non-contact participants
            if pre_status == 'H':
                if post_status == 'V':
                    print("Error found in data: humans cannot be vampires; aborting.")
                    sys.exit()
                elif post_status == 'U':
                    vk_post[participant] = 'H'
    
    # Process contact groups
    for group in contacts:
        # Check if ALL members are definitively human in pre
        group_pre_statuses = [vk_pre.get(p, 'U') for p in group]
        
        # If group is not ALL human, skip propagation
        if not all(status == 'H' for status in group_pre_statuses):
            continue
        
        # Ensure all humans remain human
        for participant in group:
            post_status = vk_post.get(participant, 'U')
            
            if post_status == 'V':
                print("Error found in data: humans cannot be vampires; aborting.")
                sys.exit()
            elif post_status == 'U':
                vk_post[participant] = 'H'
    
    return vk_post

# Section 12
def find_infection_windows(vks):
    """
    Determine the infection windows for vampires.
    
    Args:
        vks (list): List of vampire knowledge structures across time periods
    
    Returns:
        dict: Infection windows for each vampire
    """
    # Ensure we don't modify the input
    vks_copy = [dict(vk) for vk in vks]
    
    # Find all vampires in the final time period
    final_vampires = [
        participant 
        for participant, status in vks_copy[-1].items() 
        if status == 'V'
    ]
    
    # Initialize infection windows
    infection_windows = {}
    
    for vampire in final_vampires:
        # Find the start of the infection window (last definite human status)
        start = 0
        for t in range(len(vks_copy)):
            if vks_copy[t].get(vampire, 'U') == 'H':
                start = t
        
        # Find the end of the infection window (first definite vampire status)
        end = 0
        for t in range(len(vks_copy)):
            if vks_copy[t].get(vampire, 'U') == 'V':
                end = t
                break
        
        # Store the infection window
        infection_windows[vampire] = (start, end)
    
    return infection_windows

def pretty_print_infection_windows(iw):
    """
    Pretty print the infection windows.
    
    Args:
        iw (dict): Infection windows dictionary
    """
    print("Infection Windows:")
    for vampire, (start, end) in sorted(iw.items()):
        print(f"  {vampire} was turned between day {str_time(start)} and day {str_time(end)}.")


# Section 13
def find_potential_sires(iw, groups):
    """
    Determine potential sires for vampires based on the infection window and contact groups.
    
    Parameters:
        iw (dict): The infection window structure with vampires and their time windows.
        groups (list): A list of contact groups indexed by day, with PM contacts only.
    
    Returns:
        dict: A dictionary mapping vampires to a list of potential sires with time and contact details.
    """
    potential_sires = {}
    
    for vampire, time_units in iw.items():
        vampire_contacts = []
        for time_unit in sorted(time_units):  # Ensure time units are in order
            day, time = time_unit.split(' ')
            day_index = int(day[3:])  # Extract the day number
            if time == 'PM':  # Only consider PM time
                contacts = groups[day_index].get(vampire, [])  # Get contacts for the vampire
                vampire_contacts.append((time_unit, contacts if contacts else ['(None)']))
        
        potential_sires[vampire] = vampire_contacts
    
    return potential_sires


def pretty_print_potential_sires(ps):
    """
    Pretty print the potential sires structure.
    
    Parameters:
        ps (dict): The potential sires structure to be printed.
    """
    for vampire in sorted(ps):  # Alphabetical order of vampire names
        print(f"{vampire}:")
        for time_unit, contacts in ps[vampire]:
            contacts_str = ', '.join(contacts)
            print(f"    On {time_unit}, met with {contacts_str}.")
        if not ps[vampire]:  # If no contacts for the vampire
            print("    (None)")


# Section 14
def trim_potential_sires(potential_sires, vampire_knowledge):
    """
    Simplify the potential sire structure by removing invalid entries based on logical principles:
    1. Remove any empty contact days.
    2. Exclude the (eventual) vampire themselves from their contact list.
    3. Exclude humans from the contact list, as humans cannot sire vampires.

    Args:
        potential_sires (dict): Dictionary mapping individuals to their potential sire data.
        vampire_knowledge (dict): Dictionary containing vampire-related knowledge for individuals.

    Returns:
        dict: Updated potential sire structure after removing invalid entries.
    """
    updated_sires = {}

    for person, contact_data in potential_sires.items():
        updated_contacts = []
        
        for entry in contact_data:
            day, time_of_day, contacts = entry
            
            # Remove the eventual vampire themselves and any known humans from the contact list
            valid_contacts = [
                contact for contact in contacts 
                if contact != person and vampire_knowledge.get(contact) != "human"
            ]
            
            # Only include the day if there are valid contacts remaining
            if valid_contacts:
                updated_contacts.append((day, time_of_day, valid_contacts))
        
        # Add the person to the updated structure, even if their contacts are now empty
        updated_sires[person] = updated_contacts or [(None,)]

    return updated_sires


# Section 15
def trim_infection_windows(infection_windows, potential_sires):
    """
    Tighten the infection windows based on potential sire information and logical principles:
    1. For individuals with no potential sires, set the infection window to (0, 0).
    2. For others, use the earliest and latest days in the trimmed potential sire data to define the window.
    3. Vampires can only turn humans in the afternoons, so specify the time as PM when refining the window.

    Args:
        infection_windows (dict): Dictionary of individuals and their original infection windows.
        potential_sires (dict): Dictionary of individuals and their trimmed potential sire data.

    Returns:
        dict: Updated infection window structure with refined windows.
    """
    updated_windows = {}

    for person, window in infection_windows.items():
        trimmed_sires = potential_sires.get(person, [])

        if not trimmed_sires or trimmed_sires == [(None,)]:
            # No sires: set window to (0, 0)
            updated_windows[person] = (0, 0)
        else:
            # Extract the earliest and latest day from the trimmed sire data
            days = [
                day for day, time_of_day, contacts in trimmed_sires
                if day is not None
            ]
            if days:
                earliest_day = min(days)
                latest_day = max(days)
                updated_windows[person] = (f"{earliest_day} (PM)", f"{latest_day} (PM)")
            else:
                # Default to original window if no valid days are found
                updated_windows[person] = window

    return updated_windows



# Section 16
def update_vks_with_windows(vks, iw):
    """
    Update the vk structures based on the tightened infection windows.

    Parameters:
    vks (list): Time-indexed list of dictionaries representing human/vampire status.
                Each dictionary contains three keys: 'humans', 'unclear', 'vampires'.
    iw (dict): Dictionary mapping individuals to their infection windows, 
               with each window represented as (start_day, end_day).

    Returns:
    tuple: Updated vks list and the number of changes made to the vks list.

    Errors:
    - "Error found in data: humans cannot be vampires; aborting." for forward human propagation conflicts.
    - "Error found in data: vampires cannot be human; aborting." for backward vampire propagation conflicts.
    """
    changes = 0  # Track the number of changes made to vks

    for person, (start_day, end_day) in iw.items():
        for time, vk in enumerate(vks):
            if time < start_day:
                # Before the infection window, the person must be human
                if person in vk['vampires']:
                    print("Error found in data: humans cannot be vampires; aborting.")
                    exit()
                if person not in vk['humans']:
                    vk['humans'].add(person)
                    vk['unclear'].discard(person)
                    changes += 1
            elif time > end_day:
                # After the infection window, the person must be a vampire
                if person in vk['humans']:
                    print("Error found in data: vampires cannot be human; aborting.")
                    exit()
                if person not in vk['vampires']:
                    vk['vampires'].add(person)
                    vk['unclear'].discard(person)
                    changes += 1

    return vks, changes


# Section 17; done by professors
def cyclic_analysis(vks,iw,ps):
    count = 0
    changes = 1
    while(changes != 0):
        ps = trim_potential_sires(ps,vks)
        iw = trim_infection_windows(iw,ps)
        (vks,changes) = update_vks_with_windows(vks,iw)
        count = count + 1
    return (vks,iw,ps,count)



# Section 18: vampire strata
def vampire_strata(iw):
    """
    Categorize vampires into strata based on their infection windows.

    Args:
        iw (dict): A dictionary where keys are vampire names and values are tuples 
                   (start_time, end_time) representing infection windows.

    Returns:
        tuple: A triple of sets - (originals, unknowns, newborns), 
               where each set contains vampire names in that category.
    """
    originals = set()
    unknowns = set()
    newborns = set()

    for vampire, (start_time, end_time) in iw.items():
        if start_time == 0 and end_time == 0:
            originals.add(vampire)
        elif start_time > 0 and end_time > 0:
            newborns.add(vampire)
        elif start_time == 0 and end_time > 0:
            unknowns.add(vampire)

    return originals, unknowns, newborns


def pretty_print_vampire_strata(originals, unclear_vamps, newborns):
    """
    Pretty-print the vampire strata.

    Args:
        originals (set): Set of original vampires.
        unclear_vamps (set): Set of vampires with unknown strata.
        newborns (set): Set of newborn vampires.

    Returns:
        None
    """
    def format_set(vampire_set):
        return ", ".join(sorted(vampire_set)) if vampire_set else "(None)"

    print("  Original vampires:", format_set(originals))
    print("  Unknown strata vampires:", format_set(unclear_vamps))
    print("  Newborn vampires:", format_set(newborns))



# Section 19: vampire sire sets
def calculate_sire_sets(ps):
    """
    Calculate sire sets from the given ps structure.

    Args:
        ps (dict): A dictionary mapping vampires to their possible sire interactions. 
                   Keys are vampire names, and values are lists of tuples 
                   (sire_name, day, period).

    Returns:
        dict: A dictionary mapping vampire names to sets of possible sires.
    """
    ss = {}
    for vampire, interactions in ps.items():
        # Extract unique sire names from interactions
        sire_set = {sire_name for sire_name, _, _ in interactions}
        ss[vampire] = sire_set
    return ss

def pretty_print_sire_sets(ss, iw, vamps, newb):
    """
    Pretty-print the sire sets for vampires.

    Args:
        ss (dict): The sire set structure mapping vampires to their possible sires.
        iw (dict): The infection window structure mapping vampires to their start and end times.
        vamps (set): The subset of vampires to process.
        newb (bool): Flag indicating if the vampires are newborns (True) or of unknown strata (False).

    Returns:
        None
    """
    # Determine the heading
    heading = "Newborn vampires:" if newb else "Vampires of unknown strata:"
    print(heading)

    # Sort vampires for output
    sorted_vamps = sorted(vamps)

    if not sorted_vamps:
        print("  (None)")
        return

    for vampire in sorted_vamps:
        sires = ss.get(vampire, set())
        start_time, end_time = iw[vampire]

        if len(sires) == 1:
            sire = next(iter(sires))
            if start_time == end_time:
                time_phrase = f"on day {start_time} (PM)"
            else:
                time_phrase = f"between day {start_time} (PM) and day {end_time} (PM)"
            if newb:
                print(f"  {vampire} was sired by {sire} {time_phrase}.")
            else:
                print(f"  {vampire} could have been sired by {sire} {time_phrase}.")
        else:
            sires_formatted = format_list_or(sires)
            if start_time == end_time:
                time_phrase = f"on day {start_time} (PM)"
            else:
                time_phrase = f"between day {start_time} (PM) and day {end_time} (PM)"
            print(f"  {vampire} could have been sired by {sires_formatted} {time_phrase}.")



# Section 20: 
def find_hidden_vampires(ss, iw, vamps, vks):
    """
    Find hidden vampire sires and update the vampire knowledge structures (vks).
    
    Parameters:
        ss (dict): Maps newborn vampires to their sire sets.
        iw (dict): Maps vampires to their infection windows.
        vamps (set): Set of known vampires.
        vks (list): Time-indexed list of vampire knowledge structures.
    
    Returns:
        tuple: (Updated vks, Number of changes made)
    """
    changes = 0  # Track updates from U to V
    
    for vampire in vamps:
        if vampire in ss:
            sire_set = ss[vampire]
            if len(sire_set) == 1:  # Singleton sire set
                sire = next(iter(sire_set))  # Extract the single sire
                
                if sire in iw:  # Check infection window
                    infection_start, infection_end = iw[sire]
                    
                    # Propagate vampirism in the time window
                    for time in range(infection_start, infection_end + 1):
                        if sire in vks[time]['Unclear']:
                            vks[time]['Unclear'].remove(sire)
                            vks[time]['Vampires'].add(sire)
                            changes += 1
                    
                    # Extend vampirism one step back
                    if infection_start - 1 >= 0:
                        prev_time = infection_start - 1
                        if sire in vks[prev_time]['Unclear']:
                            vks[prev_time]['Unclear'].remove(sire)
                            vks[prev_time]['Vampires'].add(sire)
                            changes += 1
                        
                else:
                    print(f"Error: No infection window found for sire {sire}. Aborting.")
                    exit(1)
            
            else:
                # Multiple sires or empty sire set
                continue
    
    # Validate no vampires are marked as humans
    for time, vk in enumerate(vks):
        if any(v in vk['Humans'] for v in vk['Vampires']):
            print("Error found in data: vampires cannot be humans; aborting.")
            exit(1)
    
    return vks, changes




# Section 21; done by professor
def cyclic_analysis2(vks,groups):
    count = 0
    changes = 1
    while(changes != 0):
        iw = find_infection_windows(vks)
        ps = find_potential_sires(iw, groups)
        vks,iw,ps,countz = cyclic_analysis(vks,iw,ps)
        o,u,n = vampire_strata(iw)
        ss = calculate_sire_sets(ps)
        vks,changes = find_hidden_vampires(ss,iw,n,vks)        
        count = count + 1
    return (vks,iw,ps,ss,o,u,n,count)



def main():
    """Main logic for the program.  Do not change this (although if 
       you do so for debugging purposes that's ok if you later change 
       it back...)
    """
    filename = "DataSet2.txt"

    # Section 2. Check that the file exists
    if not file_exists(filename):
        print("File does not exist, ending program.")
        sys.exit()

    # Section 3. Create contacts dictionary from the file
    # Complete function parse_file().
    data = parse_file(filename)
    participants, days = data
    tests_by_day = [d[0] for d in days]
    groups_by_day = [d[1] for d in days]

    # Section 4. Print contact records
    pretty_print_infiltration_data(data)

    # Section 5. Create helper function for time analysis.
    print("********\nSection 5: Lookup helper function")
    if len(participants) == 0:
        print("  No participants.")
    else:
        p = participants[0]
        if len(days) > 1:
            d = 2
        elif len(days) == 1:
            d = 1
        else:
            d = 0
        t = time_of_day(d,True)
        t2 = time_of_day(d,False)
        print(f"  {p}'s contacts for time unit {t} (day {day_of_time(t)}) are {format_list(contacts_by_time(p,t,groups_by_day))}.")
        print(f"  {p}'s contacts for time unit {t2} (day {day_of_time(t2)}) are {format_list(contacts_by_time(p,t2,groups_by_day))}.")

    # Section 6.  Create the initial data structure and pretty-print it.
    print("********\nSection 6: create initial vampire knowledge tables")
    vks = [create_initial_vk(participants) for i in range(1 + (2 * len(days)))]
    pretty_print_vks(vks)

    # Section 7.  Update the VKs with test results.
    print("********\nSection 7: update the vampire knowledge tables with test results")
    for t in range(1,len(vks),2):
        vks[t] = update_vk_with_tests(vks[t],tests_by_day[day_of_time(t)-1])
    pretty_print_vks(vks)

    # Section 8.  Update the VKs to push vampirism forwards in time.
    print("********\nSection 8: update the vampire knowledge tables by forward propagation of vampire status")
    for t in range(1,len(vks)):
        vks[t] = update_vk_with_vampires_forward(vks[t-1],vks[t])
    pretty_print_vks(vks)

    # Section 9.  Update the VKs to push humanism backwards in time.
    print("********\nSection 9: update the vampire knowledge tables by backward propagation of human status")
    for t in range(len(vks)-1, 0, -1):
        vks[t-1] = update_vk_with_humans_backward(vks[t-1],vks[t])
    pretty_print_vks(vks)

    # Sections 10 and 11.  Update the VKs to account for contact groups and safety at night.
    print("********\nSections 10 and 11: update the vampire knowledge tables by forward propagation of contact results and overnight")
    for t in range(1, len(vks), 2):
        vks[t+1] = update_vk_with_contact_group(vks[t],groups_by_day[day_of_time(t)-1],vks[t+1])
        if t + 2 < len(vks):
            vks[t+2] = update_vk_overnight(vks[t+1],vks[t+2])
    pretty_print_vks(vks)

    # Section 12. Find infection windows for vampires.
    print("********\nSection 12: Vampire infection windows")
    iw = find_infection_windows(vks)
    pretty_print_infection_windows(iw)

    # Section 13. Find possible vampire sires.
    print("********\nSection 13: Find possible vampire sires")
    ps = find_potential_sires(iw, groups_by_day)
    pretty_print_potential_sires(ps)

    # Section 14. Trim the potential sire structure.
    print("********\nSection 14: Trim potential sire structure")
    ps = trim_potential_sires(ps,vks)
    pretty_print_potential_sires(ps)

    # Section 15. Trim the infection windows.
    print("********\nSection 15: Trim infection windows")
    iw = trim_infection_windows(iw,ps)
    pretty_print_infection_windows(iw)
 
    # Section 16. Update the vk structures with infection windows.
    print("********\nSection 16: Update vampire information tables with infection window data")
    (vks,changes) = update_vks_with_windows(vks,iw)
    pretty_print_vks(vks)
    str_s = "" if changes == 1 else "s"
    print(f'({changes} change{str_s})')

    # Section 17.  Cyclic analysis for sections 14-16 
    print("********\nSection 17: Cyclic analysis for sections 14-16")
    vks,iw,ps,count = cyclic_analysis(vks,iw,ps)
    str_s = "" if count == 1 else "s"    
    print(f'Detected fixed point after {count} iteration{str_s}.')
    print('Potential sires:')
    pretty_print_potential_sires(ps)
    print('Infection windows:')
    pretty_print_infection_windows(iw)
    pretty_print_vks(vks)       

    # Section 18.  Calculate vampire strata
    print("********\nSection 18: Calculate vampire strata")
    (origs,unkns,newbs) = vampire_strata(iw)
    pretty_print_vampire_strata(origs,unkns,newbs)

    # Section 19.  Calculate definite sires
    print("********\nSection 19: Calculate definite vampire sires")
    ss = calculate_sire_sets(ps)
    pretty_print_sire_sets(ss,iw,unkns,False)
    pretty_print_sire_sets(ss,iw,newbs,True)    

    # Section 20.  Find hidden vampires
    print("********\nSection 20: Find hidden vampires")
    (vks, changes) = find_hidden_vampires(ss,iw,newbs,vks)
    pretty_print_vks(vks)           
    str_s = "" if changes == 1 else "s"
    print(f'({changes} change{str_s})')

    # Section 21.  Cyclic analysis for sections 14-20
    print("********\nSection 21: Cyclic analysis for sections 14-20")
    (vks,iw,ps,ss,o,u,n,count) = cyclic_analysis2(vks,groups_by_day)
    str_s = "" if count == 1 else "s"    
    print(f'Detected fixed point after {count} iteration{str_s}.')
    print("Infection windows:")
    pretty_print_infection_windows(iw)
    print("Vampire potential sires:")
    pretty_print_potential_sires(ps)
    print("Vampire strata:")
    pretty_print_vampire_strata(o,u,n)
    print("Vampire sire sets:")    
    pretty_print_sire_sets(ss,iw,u,False)
    pretty_print_sire_sets(ss,iw,n,True)
    pretty_print_vks(vks)       
  
if __name__ == "__main__":
    main()
