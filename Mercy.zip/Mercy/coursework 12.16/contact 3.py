#!/usr/bin/env python3
"""Analyse a vampire infiltration.
   Vampire Hunting v1.4.4

   Student number:
"""

import sys
import os.path
from format_list import format_list, format_list_or, str_time, is_initial, period_of_time, day_of_time, time_of_day

import os
import sys

# Section 2: Check the file exists
def file_exists(file_name):
    """Verify that the file exists.

    Args:
        file_name (str): name of the file

    Returns:
        boolean: returns True if the file exists and False otherwise.
    """
    return os.path.isfile(file_name)

# Section 3: Parse the file and extract the relevant data
def parse_file(file_name):
    """Read the input file, parse the contents and return some data structures
    that contain the associated data for the vampire infiltration.

    Args:
        file_name (str): Contains the name of the file.

    Returns:
        participants: list of participants.
        days: list of pairs; the first element of a pair is the result of tests
          (dictionary from participants to "H"/"V"); the second is a list of
          contact groups (list of lists of participants)
    """
    participants = []
    days = []

    try:
        with open(file_name, 'r') as f:
            # Read the first line: Participants list
            participants_line = f.readline().strip()
            participants = [name.strip() for name in participants_line.split(',')]

            # Read the second line: Number of days
            num_days_line = f.readline().strip()
            num_days = int(num_days_line)

            for _ in range(num_days):
                # Read the test results for the day
                test_results_line = f.readline().strip()
                if test_results_line != "##":
                    test_results = {}
                    test_results_parts = test_results_line.split(',')
                    for part in test_results_parts:
                        name, result = part.split(':')
                        test_results[name.strip()] = True if result.strip() == 'V' else False
                else:
                    test_results = {}

                # Read the number of contact groups
                num_groups_line = f.readline().strip()
                num_groups = int(num_groups_line)

                # Read the contact groups
                contact_groups = []
                for _ in range(num_groups):
                    contact_group_line = f.readline().strip()
                    contact_group = [name.strip() for name in contact_group_line.split(',')]
                    contact_groups.append(contact_group)

                # Store the day's data as a tuple of test results and contact groups
                days.append((test_results, contact_groups))

            return (participants, days)
    
    except ValueError:
        # Handle errors in case of incorrect data format (e.g., non-integer values)
        print("Error found in file, aborting.")
        sys.exit()
    except Exception as e:
        # Handle any other errors, like file not found
        print(f"Error reading file: {e}")
        sys.exit()

#section 4
def pretty_print_infiltration_data(data):
    """Pretty print the vampire infiltration data in a human-readable format."""
    
    # Header
    print("Vampire Infiltration Data")
    
    # Participants and Day Count
    participants = data[0]
    num_days = len(data[1])
    print(f"{num_days} days with the following participants: {format_list(participants)}.")
    
    # Iterate through each day and print the relevant information
    for day_num, day_data in enumerate(data[1], start=1):
        # Extract vampire test results and contact groups
        vampire_tests, contact_groups = day_data
        test_results = sorted(vampire_tests.items())  # Sort by participant names
        
        # Day number and number of tests/groups
        num_tests = len(test_results)
        num_groups = len(contact_groups)
        print(f"Day {day_num} has {num_tests} vampire test{'s' if num_tests > 1 else ''} and {num_groups} contact group{'s' if num_groups > 1 else ''}.")
        
        # Print test results (2 spaces indent, 4 spaces for each participant)
        print(f"  {num_tests} test{'s' if num_tests > 1 else ''}")
        for participant, is_vampire in test_results:
            status = "vampire!" if is_vampire else "human."
            print(f"    {participant} is a {status}")
        
        # Print contact groups (2 spaces indent, 4 spaces for each group)
        print(f"  {num_groups} group{'s' if num_groups > 1 else ''}")
        for group in contact_groups:
            print(f"    {', '.join(group)}")
    
    # End of the data
    print("End of Days")

# Section 5
def contacts_by_time(participant, time, contacts_daily):
    """
    Returns a list of participants that the given participant (participant) met on the specified time (time unit).
    
    Args:
        participant (str): The name of the participant.
        time (int): The time unit (AM or PM), which corresponds to the day and period.
        contacts_daily (list): A list of contact groups for each day.
        
    Returns:
        list: A list of participants the given participant met at the specified time.
    """
    # If the time is in the initial period (day 0), there are no contacts.
    if time == 0:
        return []

    # Convert the time unit into the corresponding day (1-based index).
    day = day_of_time(time) - 1  # Convert to 0-based index for contacts_daily

    # If it's day 0, return an empty list since there are no contacts on day 0.
    if day == 0:
        return []

    # Get the contact groups for the given day.
    groups = contacts_daily[day]

    # Initialize an empty list to store contacts for the given participant.
    participant_contacts = []

    # Search through the groups for the given day to find the participant and their contacts.
    for group in groups:
        if participant in group:
            # Add all participants from this group (except the current participant).
            participant_contacts.extend([p for p in group if p != participant])

    # Return the list of contacts for the given participant at the specified time.
    return participant_contacts
    
# Section 6

def create_initial_vk(participants):
    """Create the initial vampire knowledge structure with all participants having 'U' (unclear) status."""
    # Initialize the dictionary with all participants marked as unclear ('U')
    return {participant: 'U' for participant in participants}

def pretty_print_vampire_knowledge(vk):
    """Pretty print the current vampire knowledge structure."""
    # Categorize participants based on their status
    humans = sorted([name for name, status in vk.items() if status == 'H'])
    vampires = sorted([name for name, status in vk.items() if status == 'V'])
    unclear = sorted([name for name, status in vk.items() if status == 'U'])

    # Format and print each category
    print(f"  Humans: {format_list(humans)}")
    print(f"  Unclear individuals: {format_list(unclear)}")
    print(f"  Vampires: {format_list(vampires)}")

# Done by professors
def pretty_print_vks(vks):
    """Pretty print the vampire knowledge for each day."""
    print(f'Vampire Knowledge Tables')
    for i in range(len(vks)):
        print(f'Day {str_time(i)}:')
        pretty_print_vampire_knowledge(vks[i])
    print(f'End Vampire Knowledge Tables')  # Section 6. Create the initial data structure and pretty-print it.

# Section 7
import sys

def update_vk_with_tests(vk, tests):
    """Update the vampire knowledge structure with test results."""
    # Iterate over each participant in the tests dictionary
    for participant, test_result in tests.items():
        # Check if the participant is valid
        if participant not in vk:
            print(f"Error found in data: test subject is not a participant; aborting.")
            sys.exit()
        
        current_status = vk[participant]
        
        # Check if there are errors based on the current status and test result
        if current_status == 'H' and test_result:  # Human tests positive for vampirism
            print(f"Error found in data: humans cannot be vampires; aborting.")
            sys.exit()
        elif current_status == 'V' and not test_result:  # Vampire tests negative for vampirism
            print(f"Error found in data: vampires cannot be humans; aborting.")
            sys.exit()
        
        # Update the status if the current status is unclear ('U')
        if current_status == 'U':
            if test_result:  # Positive test, mark as vampire
                vk[participant] = 'V'
            else:  # Negative test, mark as human
                vk[participant] = 'H'
    
    return vk

# Done by professors
def pretty_print_vks(vks):
    """Pretty print the vampire knowledge for each day."""
    print(f'Vampire Knowledge Tables')
    for i in range(len(vks)):
        print(f'Day {str_time(i)}:')
        pretty_print_vampire_knowledge(vks[i])
    print(f'End Vampire Knowledge Tables')


# Section 8
def update_vk_with_vampires_forward(vk_pre, vk_post):
    """ Propagate vampire status from the pre-period (vk_pre) to the post-period (vk_post). """
    
    for participant, pre_status in vk_pre.items():
        post_status = vk_post.get(participant, 'U')  # Default to 'U' if participant is not in vk_post
        
        if pre_status == 'V':  # The participant is a vampire in vk_pre
            if post_status == 'H':  # Error: A vampire cannot be human
                print("Error found in data: vampires cannot be humans; aborting.")
                sys.exit()
            elif post_status == 'U':  # Update unknown status to vampire
                vk_post[participant] = 'V'
        
        # If the participant wasn't a vampire in vk_pre, no change is made in vk_post
        # Only propagate if they are confirmed as a vampire in vk_pre
    
    return vk_post
# Section 9
import sys

def update_vk_with_humans_backward(vk_pre, vk_post):
    """ Propagate human status from the post-period (vk_post) to the pre-period (vk_pre). """
    
    for participant, post_status in vk_post.items():
        pre_status = vk_pre.get(participant, 'U')  # Default to 'U' if participant is not in vk_pre
        
        if post_status == 'H':  # The participant is human in vk_post
            if pre_status == 'V':  # Error: A human cannot be a vampire in the past
                print("Error found in data: humans cannot be vampires; aborting.")
                sys.exit()
            elif pre_status == 'U':  # Update unknown status to human
                vk_pre[participant] = 'H'
        
        # If the participant was not human in vk_post, no change is made in vk_pre
    
    return vk_pre


# Section 10
import sys

def update_vk_overnight(vk_pre, vk_post):
    """
    Propagate human/vampire status forward overnight.
    
    Logical principle 4: Everyone is safe at night. Humans remain human.
    
    Args:
        vk_pre (dict): Vampire knowledge structure before overnight period
        vk_post (dict): Vampire knowledge structure after overnight period
    
    Returns:
        dict: Updated post-overnight vampire knowledge structure
    """
    for participant, pre_status in vk_pre.items():
        post_status = vk_post.get(participant, 'U')  # Default to 'U' if not in post
        
        # Error conditions
        if pre_status == 'H' and post_status == 'V':
            print("Error found in data: humans cannot be vampires; aborting.")
            sys.exit()
        elif pre_status == 'V' and post_status == 'H':
            print("Error found in data: vampires cannot be humans; aborting.")
            sys.exit()
        
        # Propagate definite statuses
        if pre_status == 'H' and post_status == 'U':
            vk_post[participant] = 'H'
        elif pre_status == 'V' and post_status == 'U':
            vk_post[participant] = 'V'
    
    return vk_post

def update_vk_with_contact_group(vk_pre, contacts, vk_post):
    """
    Update vampire knowledge based on contact groups.
    
    Logical principle 5: Vampires might turn humans during contacts.
    
    Args:
        vk_pre (dict): Vampire knowledge structure before contacts
        contacts (list): List of contact groups (each group is a list of participants)
        vk_post (dict): Vampire knowledge structure after contacts
    
    Returns:
        dict: Updated post-contact vampire knowledge structure
    """
    # First, validate participants and propagate known vampire statuses
    for participant, pre_status in vk_pre.items():
        post_status = vk_post.get(participant, 'U')
        
        # Check for impossible status transitions
        if pre_status == 'V' and post_status == 'H':
            print("Error found in data: vampires cannot be human; aborting.")
            sys.exit()
        
        # Propagate known vampire status
        if pre_status == 'V' and post_status == 'U':
            vk_post[participant] = 'V'
    
    # Validate contact group participants
    for group in contacts:
        for participant in group:
            if participant not in vk_pre:
                print("Error found in data: contact subject is not a participant; aborting.")
                sys.exit()
    
    # Process non-contact participants
    all_contact_participants = set(participant 
                                   for group in contacts 
                                   for participant in group)
    
    for participant, pre_status in vk_pre.items():
        if participant not in all_contact_participants:
            post_status = vk_post.get(participant, 'U')
            
            # Propagate known human status for non-contact participants
            if pre_status == 'H':
                if post_status == 'V':
                    print("Error found in data: humans cannot be vampires; aborting.")
                    sys.exit()
                elif post_status == 'U':
                    vk_post[participant] = 'H'
    
    # Process contact groups
    for group in contacts:
        # Check if ALL members are definitively human in pre
        group_pre_statuses = [vk_pre.get(p, 'U') for p in group]
        
        # If group is not ALL human, skip propagation
        if not all(status == 'H' for status in group_pre_statuses):
            continue
        
        # Ensure all humans remain human
        for participant in group:
            post_status = vk_post.get(participant, 'U')
            
            if post_status == 'V':
                print("Error found in data: humans cannot be vampires; aborting.")
                sys.exit()
            elif post_status == 'U':
                vk_post[participant] = 'H'
    
    return vk_post

# Section 12
def find_infection_windows(vks):
    """
    Determine the infection windows for vampires.
    
    Args:
        vks (list): List of vampire knowledge structures across time periods
    
    Returns:
        dict: Infection windows for each vampire
    """
    # Ensure we don't modify the input
    vks_copy = [dict(vk) for vk in vks]
    
    # Find all vampires in the final time period
    final_vampires = [
        participant 
        for participant, status in vks_copy[-1].items() 
        if status == 'V'
    ]
    
    # Initialize infection windows
    infection_windows = {}
    
    for vampire in final_vampires:
        # Find the start of the infection window (last definite human status)
        start = 0
        for t in range(len(vks_copy)):
            if vks_copy[t].get(vampire, 'U') == 'H':
                start = t
        
        # Find the end of the infection window (first definite vampire status)
        end = 0
        for t in range(len(vks_copy)):
            if vks_copy[t].get(vampire, 'U') == 'V':
                end = t
                break
        
        # Store the infection window
        infection_windows[vampire] = (start, end)
    
    return infection_windows

def pretty_print_infection_windows(iw):
    """
    Pretty print the infection windows.
    
    Args:
        iw (dict): Infection windows dictionary
    """
    print("Infection Windows:")
    for vampire, (start, end) in sorted(iw.items()):
        print(f"  {vampire} was turned between day {str_time(start)} and day {str_time(end)}.")


# Section 13
def find_potential_sires(iw, groups):
    """
    Find potential sires for each vampire.
    
    Args:
        iw (dict): Infection windows dictionary
        groups (list): List of contact groups indexed by day
    
    Returns:
        dict: Potential sires information
    """
    potential_sires = {}
    
    for vampire, (start, end) in sorted(iw.items()):
        # Find PM time units within the infection window
        vampire_contacts = []
        
        # Iterate through possible PM time units
        for t in range(start + 1, end + 1):
            # Only consider PM time units
            if not period_of_time(t):
                # Get the corresponding day index (subtract 1 for 0-based indexing)
                day_index = day_of_time(t) - 1
                
                # Check if day is within valid groups range and group exists
                if 0 <= day_index < len(groups):
                    # Store the contact group for this time unit
                    vampire_contacts.append((t, groups[day_index]))
        
        # If no contacts found, set to empty list
        potential_sires[vampire] = vampire_contacts if vampire_contacts else []
    
    return potential_sires

def pretty_print_potential_sires(ps):
    """
    Pretty print the potential sires information.
    
    Args:
        ps (dict): Potential sires dictionary
    """
    print("Potential Sires:")
    
    for vampire, contacts in sorted(ps.items()):
        print(f"  {vampire}:", end=" ")
        
        if not contacts:
            print("(None)")
        else:
            print()  # New line after vampire name
            for time, group in contacts:
                print(f"    On day {str_time(time)}, met with {format_list(group)}.")

# Section 14
def trim_potential_sires(ps, vks):
    """
    Trim potential sires based on vampirism rules.

    Args:
        ps (dict): Potential sires dictionary (vampires as keys, list of contacts as values)
        vks (list): List of vampire knowledge structures (dictionary per day)

    Returns:
        dict: Updated potential sires dictionary
    """
    # Create a copy to avoid modifying the original dictionary
    trimmed_ps = {}
    
    for vampire, contacts in ps.items():
        # Filter out empty contact lists
        if not contacts:
            trimmed_ps[vampire] = []
            continue
        
        # Create a new list of filtered contacts
        filtered_contacts = []
        
        for time, group in contacts:
            # Flatten the group if it's a list of lists
            flat_group = [member for sublist in group for member in (sublist if isinstance(sublist, list) else [sublist])]
            
            # Remove the vampire from the group for sire consideration
            filtered_group = [person for person in flat_group if person != vampire]
            
            # Filter out humans first, since only vampires can sire others
            vampire_group = [
                person for person in filtered_group
                if vks[day_of_time(time) - 1].get(person, 'U') == 'V'
            ]
            
            # If there is exactly one person in the filtered group, they could be the sire
            if len(filtered_group) == 1 and vampire_group:
                # The one person in the group might be the one who sired the vampire, even if they are human
                filtered_contacts.append((time, vampire_group))
            else:
                # Otherwise, we only add vampires as potential sires
                if vampire_group:
                    filtered_contacts.append((time, vampire_group))
        
        # Store the filtered contacts in the trimmed_ps
        trimmed_ps[vampire] = filtered_contacts
    
    return trimmed_ps


# Section 15
def trim_infection_windows(iw, ps):
    """
    Tighten infection windows based on trimmed potential sires information.
    
    Args:
        iw (dict): Infection window structure (vampire -> (start_day, end_day)).
        ps (dict): Trimmed potential sires structure (vampire -> list of contact days).
    
    Returns:
        dict: Updated infection window structure
    """
    # Create a copy of the infection windows to avoid modifying the original
    updated_iw = {}
    
    for vampire, (start_day, end_day) in iw.items():
        # If the vampire has no potential sires, they must have been turned at the beginning
        if vampire not in ps or not ps[vampire]:
            updated_iw[vampire] = (0, 0)
            continue
        
        # Otherwise, find the first and last day of contact
        min_day = float('inf')  # Initialize to a large number
        max_day = -float('inf')  # Initialize to a small number
        
        for time, group in ps[vampire]:
            # Convert the day of time to the day number (we assume time is in the form of (day, period))
            day_number = day_of_time(time)
            
            # Update the min and max days based on the contacts
            min_day = min(min_day, day_number)
            max_day = max(max_day, day_number)
        
        # Update the infection window based on the new min and max days
        updated_iw[vampire] = (min_day, max_day)
        
    return updated_iw

# Section 16
def update_vks_with_windows(vks, iw):
    """
    Update vampire knowledge structures based on infection windows.
    
    Args:
        vks (list): Time-indexed vampire knowledge structures
        iw (dict): Infection windows for vampires
    
    Returns:
        tuple: Updated vks list and number of changes
    """
    # Create a new list of vks with the same structure as the original
    updated_vks = [dict(day_vk) for day_vk in vks]
    changes = 0
    
    # Process each vampire's infection window
    for vampire, (start_day, end_day) in sorted(iw.items()):
        for day_index, day_vk in enumerate(updated_vks):
            # If vampire is unknown, update based on infection window
            if day_vk.get(vampire, 'U') == 'U':
                # Before start day: must be human
                if day_index < start_day:
                    updated_vks[day_index][vampire] = 'H'
                    changes += 1
                
                # After end day: must be vampire
                elif day_index > end_day:
                    updated_vks[day_index][vampire] = 'V'
                    changes += 1
    
    return (updated_vks, changes)
# Section 17; done by professors
def cyclic_analysis(vks,iw,ps):
    count = 0
    changes = 1
    while(changes != 0):
        ps = trim_potential_sires(ps,vks)
        iw = trim_infection_windows(iw,ps)
        (vks,changes) = update_vks_with_windows(vks,iw)
        count = count + 1
    return (vks,iw,ps,count)

# Section 18: vampire strata
def vampire_strata(iw):
    """
    Classify vampires into strata based on their infection windows.
    
    Args:
        iw (dict): Infection windows dictionary
    
    Returns:
        tuple: Sets of (originals, unclear_vamps, newborns)
    """
    originals = set()
    unclear_vamps = set()
    newborns = set()
    
    for vampire, (start_day, end_day) in iw.items():
        # Original vampires: infection window starts and ends at zero
        if start_day == 0 and end_day == 0:
            originals.add(vampire)
        
        # Newborn vampires: infection window starts after zero
        elif start_day > 0:
            newborns.add(vampire)
        
        # Unclear vampires: infection window starts at zero but ends after zero
        elif start_day == 0 and end_day > 0:
            unclear_vamps.add(vampire)
    
    return (originals, unclear_vamps, newborns)

def pretty_print_vampire_strata(originals, unclear_vamps, newborns):
    """
    Pretty print the vampire strata classification.
    
    Args:
        originals (set): Set of original vampires
        unclear_vamps (set): Set of vampires with unclear origin
        newborns (set): Set of newborn vampires
    """
    # Print original vampires
    print("Original vampires:", end=" ")
    if originals:
        print(", ".join(sorted(originals)))
    else:
        print("(None)")
    
    # Print unclear vampires
    print("Unknown strata vampires:", end=" ")
    if unclear_vamps:
        print(", ".join(sorted(unclear_vamps)))
    else:
        print("(None)")
    
    # Print newborn vampires
    print("Newborn vampires:", end=" ")
    if newborns:
        print(", ".join(sorted(newborns)))
    else:
        print("(None)")
# Section 19: vampire sire sets
def calculate_sire_sets(ps):
    """
    Calculate possible sire sets for vampires.
    
    Args:
        ps (dict): Potential sires dictionary
    
    Returns:
        dict: Sire sets for each vampire
    """
    # Initialize sire sets dictionary
    ss = {}
    
    # For each vampire in the potential sires dictionary
    for vampire, contacts in ps.items():
        # Create a set of possible sires by extracting unique sires from contacts
        sire_set = set()
        for _, group in contacts:
            # Flatten the group if it's a list of lists
            flat_group = [member for sublist in group for member in (sublist if isinstance(sublist, list) else [sublist])]
            
            # Add unique sires to the set
            sire_set.update(flat_group)
        
        ss[vampire] = sire_set
    
    return ss

def pretty_print_sire_sets(ss, iw, vamps, newb):
    """
    Pretty print sire sets with context-specific language.
    
    Args:
        ss (dict): Sire sets dictionary
        iw (dict): Infection windows dictionary
        vamps (set): Set of vampires to print
        newb (bool): Flag for newborn (True) or unknown strata (False)
    """
    # Filter and sort vampires
    relevant_vamps = sorted(vamps.intersection(ss.keys()))
    
    # First line based on whether there are relevant vampires
    if not relevant_vamps:
        print("Vampires of unknown strata: (None)" if not newb else "Newborn vampires: (None)")
        return
    
    # Print header based on newb flag
    print("Vampires of unknown strata:" if not newb else "Newborn vampires:")
    
    # Process each vampire
    for vampire in relevant_vamps:
        # Skip if no possible sires
        if not ss[vampire]:
            continue
        
        # Prepare language based on newborn or unknown status
        sire_lang = "was sired by" if newb else "could have been sired by"
        
        # Determine time language
        start, end = iw[vampire]
        if start == end:
            time_lang = f"on day {str_time(start)}"
        else:
            time_lang = f"between day {str_time(start)} and day {str_time(end)}"
        
        # Format possible sires
        if len(ss[vampire]) == 1:
            # Single sire case
            sire = list(ss[vampire])[0]
            print(f"  {vampire} {sire_lang} {sire} {time_lang}.")
        else:
            # Multiple possible sires
            sire_list = sorted(ss[vampire])
            print(f"  {vampire} {sire_lang} {format_list_or(sire_list)} {time_lang}.")

def find_hidden_vampires(ss, iw, vamps, vks):
    """
    Find hidden vampires by analyzing sire sets for newborn vampires.
    
    Args:
        ss (dict): Sire sets dictionary
        iw (dict): Infection windows dictionary
        vamps (set): Set of newborn vampires
        vks (list): Time-indexed vampire knowledge structures
    
    Returns:
        tuple: Updated vks list and number of changes
    """
    # Create a copy of vks to avoid modifying the original
    updated_vks = [dict(day_vk) for day_vk in vks]
    changes = 0
    
    # Process each newborn vampire
    for vampire in sorted(vamps):
        # Skip if no sires or multiple sires
        if len(ss[vampire]) != 1:
            continue
        
        # Get the single sire
        sire = list(ss[vampire])[0]
        
        # Get the infection window end time
        _, end_day = iw[vampire]
        
        # Check if the sire is already a human
        for day_index in range(end_day + 1):
            if updated_vks[day_index].get(sire, 'U') == 'H':
                print("Error found in data: vampires cannot be humans; aborting.")
                exit()
        
        # Update sire's status from the infection window end 
        # and one time unit before (to prevent mutual siring)
        update_days = [end_day]
        if end_day > 0:
            update_days.append(end_day - 1)
        
        for day_index in update_days:
            # Update only if currently unknown
            if updated_vks[day_index].get(sire, 'U') == 'U':
                updated_vks[day_index][sire] = 'V'
                changes += 1
        
        # Propagate vampire status forward from the last updated day
        for day_index in range(end_day + 1, len(updated_vks)):
            # Stop if sire is already a vampire
            if updated_vks[day_index].get(sire, 'U') == 'V':
                break
            
            # Check if sire is human before updating
            if updated_vks[day_index].get(sire, 'U') == 'H':
                print("Error found in data: vampires cannot be humans; aborting.")
                exit()
            
            # Update to vampire and increment changes
            updated_vks[day_index][sire] = 'V'
            changes += 1
    
    return (updated_vks, changes)

# Section 21; done by professor
def cyclic_analysis2(vks,groups):
    count = 0
    changes = 1
    while(changes != 0):
        iw = find_infection_windows(vks)
        ps = find_potential_sires(iw, groups)
        vks,iw,ps,countz = cyclic_analysis(vks,iw,ps)
        o,u,n = vampire_strata(iw)
        ss = calculate_sire_sets(ps)
        vks,changes = find_hidden_vampires(ss,iw,n,vks)        
        count = count + 1
    return (vks,iw,ps,ss,o,u,n,count)

def main():
    """Main logic for the program.  Do not change this (although if 
       you do so for debugging purposes that's ok if you later change 
       it back...)
    """
    filename = "DataSet2.txt"

    # Section 2. Check that the file exists
    if not file_exists(filename):
        print("File does not exist, ending program.")
        sys.exit()

    # Section 3. Create contacts dictionary from the file
    # Complete function parse_file().
    data = parse_file(filename)
    participants, days = data
    tests_by_day = [d[0] for d in days]
    groups_by_day = [d[1] for d in days]

    # Section 4. Print contact records
    pretty_print_infiltration_data(data)

    # Section 5. Create helper function for time analysis.
    print("********\nSection 5: Lookup helper function")
    if len(participants) == 0:
        print("  No participants.")
    else:
        p = participants[0]
        if len(days) > 1:
            d = 2
        elif len(days) == 1:
            d = 1
        else:
            d = 0
        t = time_of_day(d,True)
        t2 = time_of_day(d,False)
        print(f"  {p}'s contacts for time unit {t} (day {day_of_time(t)}) are {format_list(contacts_by_time(p,t,groups_by_day))}.")
        print(f"  {p}'s contacts for time unit {t2} (day {day_of_time(t2)}) are {format_list(contacts_by_time(p,t2,groups_by_day))}.")

    # Section 6.  Create the initial data structure and pretty-print it.
    print("********\nSection 6: create initial vampire knowledge tables")
    vks = [create_initial_vk(participants) for i in range(1 + (2 * len(days)))]
    pretty_print_vks(vks)

    # Section 7.  Update the VKs with test results.
    print("********\nSection 7: update the vampire knowledge tables with test results")
    for t in range(1,len(vks),2):
        vks[t] = update_vk_with_tests(vks[t],tests_by_day[day_of_time(t)-1])
    pretty_print_vks(vks)

    # Section 8.  Update the VKs to push vampirism forwards in time.
    print("********\nSection 8: update the vampire knowledge tables by forward propagation of vampire status")
    for t in range(1,len(vks)):
        vks[t] = update_vk_with_vampires_forward(vks[t-1],vks[t])
    pretty_print_vks(vks)

    # Section 9.  Update the VKs to push humanism backwards in time.
    print("********\nSection 9: update the vampire knowledge tables by backward propagation of human status")
    for t in range(len(vks)-1, 0, -1):
        vks[t-1] = update_vk_with_humans_backward(vks[t-1],vks[t])
    pretty_print_vks(vks)

    # Sections 10 and 11.  Update the VKs to account for contact groups and safety at night.
    print("********\nSections 10 and 11: update the vampire knowledge tables by forward propagation of contact results and overnight")
    for t in range(1, len(vks), 2):
        vks[t+1] = update_vk_with_contact_group(vks[t],groups_by_day[day_of_time(t)-1],vks[t+1])
        if t + 2 < len(vks):
            vks[t+2] = update_vk_overnight(vks[t+1],vks[t+2])
    pretty_print_vks(vks)

    # Section 12. Find infection windows for vampires.
    print("********\nSection 12: Vampire infection windows")
    iw = find_infection_windows(vks)
    pretty_print_infection_windows(iw)

    # Section 13. Find possible vampire sires.
    print("********\nSection 13: Find possible vampire sires")
    ps = find_potential_sires(iw, groups_by_day)
    pretty_print_potential_sires(ps)

    # Section 14. Trim the potential sire structure.
    print("********\nSection 14: Trim potential sire structure")
    ps = trim_potential_sires(ps,vks)
    pretty_print_potential_sires(ps)

    # Section 15. Trim the infection windows.
    print("********\nSection 15: Trim infection windows")
    iw = trim_infection_windows(iw,ps)
    pretty_print_infection_windows(iw)
 
    # Section 16. Update the vk structures with infection windows.
    print("********\nSection 16: Update vampire information tables with infection window data")
    (vks,changes) = update_vks_with_windows(vks,iw)
    pretty_print_vks(vks)
    str_s = "" if changes == 1 else "s"
    print(f'({changes} change{str_s})')

    # Section 17.  Cyclic analysis for sections 14-16 
    print("********\nSection 17: Cyclic analysis for sections 14-16")
    vks,iw,ps,count = cyclic_analysis(vks,iw,ps)
    str_s = "" if count == 1 else "s"    
    print(f'Detected fixed point after {count} iteration{str_s}.')
    print('Potential sires:')
    pretty_print_potential_sires(ps)
    print('Infection windows:')
    pretty_print_infection_windows(iw)
    pretty_print_vks(vks)       

    # Section 18.  Calculate vampire strata
    print("********\nSection 18: Calculate vampire strata")
    (origs,unkns,newbs) = vampire_strata(iw)
    pretty_print_vampire_strata(origs,unkns,newbs)

    # Section 19.  Calculate definite sires
    print("********\nSection 19: Calculate definite vampire sires")
    ss = calculate_sire_sets(ps)
    pretty_print_sire_sets(ss,iw,unkns,False)
    pretty_print_sire_sets(ss,iw,newbs,True)    

    # Section 20.  Find hidden vampires
    print("********\nSection 20: Find hidden vampires")
    (vks, changes) = find_hidden_vampires(ss,iw,newbs,vks)
    pretty_print_vks(vks)           
    str_s = "" if changes == 1 else "s"
    print(f'({changes} change{str_s})')

    # Section 21.  Cyclic analysis for sections 14-20
    print("********\nSection 21: Cyclic analysis for sections 14-20")
    (vks,iw,ps,ss,o,u,n,count) = cyclic_analysis2(vks,groups_by_day)
    str_s = "" if count == 1 else "s"    
    print(f'Detected fixed point after {count} iteration{str_s}.')
    print("Infection windows:")
    pretty_print_infection_windows(iw)
    print("Vampire potential sires:")
    pretty_print_potential_sires(ps)
    print("Vampire strata:")
    pretty_print_vampire_strata(o,u,n)
    print("Vampire sire sets:")    
    pretty_print_sire_sets(ss,iw,u,False)
    pretty_print_sire_sets(ss,iw,n,True)
    pretty_print_vks(vks)       
  
if __name__ == "__main__":
    main()
