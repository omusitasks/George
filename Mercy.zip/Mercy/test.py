# Section 13
def find_potential_sires(iw, groups):
    """
    Find potential sires for each vampire.
    
    Args:
        iw (dict): Infection windows dictionary
        groups (list): List of contact groups indexed by day
    
    Returns:
        dict: Potential sires information
    """
    potential_sires = {}
    
    for vampire, (start, end) in sorted(iw.items()):
        # Find PM time units within the infection window
        vampire_contacts = []
        
        # Iterate through possible PM time units
        for t in range(start + 1, end + 1):
            # Only consider PM time units
            if not period_of_time(t):
                # Get the corresponding day index (subtract 1 for 0-based indexing)
                day_index = day_of_time(t) - 1
                
                # Check if day is within valid groups range and group exists
                if 0 <= day_index < len(groups):
                    # Store the contact group for this time unit
                    vampire_contacts.append((t, groups[day_index]))
        
        # If no contacts found, set to empty list
        potential_sires[vampire] = vampire_contacts if vampire_contacts else []
    
    return potential_sires

def pretty_print_potential_sires(ps):
    """
    Pretty print the potential sires information.
    
    Args:
        ps (dict): Potential sires dictionary
    """
    print("Potential Sires:")
    
    for vampire, contacts in sorted(ps.items()):
        print(f"  {vampire}:", end=" ")
        
        if not contacts:
            print("(None)")
        else:
            print()  # New line after vampire name
            for time, group in contacts:
                print(f"    On day {str_time(time)}, met with {format_list(group)}.")



if __name__ == "__main__":
    main()
